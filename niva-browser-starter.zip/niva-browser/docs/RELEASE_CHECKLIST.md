# Release checklist

- [ ] Multi-tab support and lifecycle tests
- [ ] Bookmarks, history and downloads
- [ ] Clear-data and privacy dashboard
- [ ] Permission rationale and safe external-link handling
- [ ] Private backend deployed with HTTPS
- [ ] AI requests require user consent and use server-side secrets
- [ ] Privacy policy and support contact published
- [ ] Play Console Data safety form completed accurately
- [ ] App icon, screenshots and store listing prepared
- [ ] Release signing key created and backed up securely (never commit it)
- [ ] Signed AAB tested through Play internal testing
