package com.niva.browser

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private val Ink = Color(0xFF101412)
private val Panel = Color(0xFF1A211E)
private val Mint = Color(0xFFB9F3D1)
private val Muted = Color(0xFF9AA9A1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NivaBrowser() }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun NivaBrowser() {
    var address by remember { mutableStateOf("https://www.google.com") }
    var currentUrl by remember { mutableStateOf("https://www.google.com") }
    var pageTitle by remember { mutableStateOf("New tab") }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var browser by remember { mutableStateOf<WebView?>(null) }

    fun navigate(input: String) {
        val value = input.trim()
        if (value.isBlank()) return
        val target = when {
            value.startsWith("https://") || value.startsWith("http://") -> value
            value.contains(" ") || !value.contains(".") ->
                "https://www.google.com/search?q=" + value.replace(" ", "+")
            else -> "https://$value"
        }
        address = target
        browser?.loadUrl(target)
    }

    BackHandler(enabled = canGoBack) { browser?.goBack() }

    Column(Modifier.fillMaxSize().background(Ink)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 20.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("NIVA", color = Color.White, fontSize = 25.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                Text("A calmer way to explore", color = Muted, fontSize = 11.sp)
            }
            Surface(color = Panel, shape = CircleShape) {
                Text("AI", Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    color = Mint, fontWeight = FontWeight.SemiBold)
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
                .background(Panel, RoundedCornerShape(18.dp))
                .padding(horizontal = 14.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Search, contentDescription = null, tint = Muted,
                modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = address,
                onValueChange = { address = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { navigate(address) }),
                decorationBox = { inner ->
                    if (address.isEmpty()) Text("Search or enter address", color = Muted, fontSize = 14.sp)
                    inner()
                }
            )
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = { navigate(address) }) {
                Text("GO", color = Mint, fontWeight = FontWeight.Bold)
            }
        }

        if (progress < 1f) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = Mint,
                trackColor = Ink
            )
        } else {
            Spacer(Modifier.height(2.dp))
        }

        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.loadsImagesAutomatically = true
                    settings.javaScriptCanOpenWindowsAutomatically = false
                    settings.setSupportMultipleWindows(false)
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(
                            view: WebView?, request: WebResourceRequest?
                        ): Boolean {
                            val scheme = request?.url?.scheme ?: return true
                            return scheme != "https" && scheme != "http"
                        }
                        override fun onPageStarted(
                            view: WebView?, url: String?, favicon: android.graphics.Bitmap?
                        ) {
                            url?.let { currentUrl = it; address = it }
                            progress = 0.08f
                        }
                        override fun onPageFinished(view: WebView?, url: String?) {
                            url?.let { currentUrl = it; address = it }
                            pageTitle = view?.title ?: "Web page"
                            canGoBack = view?.canGoBack() == true
                            canGoForward = view?.canGoForward() == true
                            progress = 1f
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            progress = newProgress / 100f
                        }
                    }
                    browser = this
                    loadUrl(currentUrl)
                }
            },
            update = { browser = it }
        )

        Text(pageTitle, color = Muted, fontSize = 11.sp, maxLines = 1,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp))

        Row(
            Modifier.fillMaxWidth().background(Panel).navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { browser?.goBack() }, enabled = canGoBack) {
                Icon(Icons.Default.ArrowBack, "Back", tint = if (canGoBack) Color.White else Muted)
            }
            IconButton(onClick = { browser?.goForward() }, enabled = canGoForward) {
                Icon(Icons.Default.ArrowForward, "Forward", tint = if (canGoForward) Color.White else Muted)
            }
            IconButton(onClick = { browser?.loadUrl("https://www.google.com") }) {
                Icon(Icons.Default.Home, "Home", tint = Mint)
            }
            IconButton(onClick = { browser?.reload() }) {
                Icon(Icons.Default.Refresh, "Reload", tint = Color.White)
            }
            IconButton(onClick = { /* Multi-tab manager is a planned milestone. */ }) {
                Icon(Icons.Default.Tab, "Tabs", tint = Color.White)
            }
            IconButton(onClick = { /* Browser menu is a planned milestone. */ }) {
                Icon(Icons.Default.MoreHoriz, "More", tint = Color.White)
            }
        }
    }
}
