# NIVA Browser
Premium Android browser foundation using Kotlin, Jetpack Compose and Android System WebView.

## Current scope
This is the initial runnable app foundation, not a completed Play Store release. It includes a browser shell, URL/search input, WebView navigation, back/forward/home/reload controls and a dark premium visual direction.

## Open
Open the `android` folder in Android Studio and sync Gradle. Use JDK 17 and Android SDK 35.

## Planned next milestones
Tabs, bookmarks, history, downloads, privacy dashboard, settings, AI page assistant via private backend, tests, privacy policy, signed AAB and Play internal testing.

## Security
Never put AI provider secrets, Supabase service-role keys, passwords or signing keys in the Android app or public repository. Backend implementation must live in a private repository/deployment.
